//import React, { createContext, useState } from "react";

//export const TitleNameContext = createContext();

//export function TitleNameProvider({ children }) {
//    const [titlename, setTitlename] = useState("");
//    return (
//        <TitleNameContext.Provider value={{ titlename, setTitlename }}>
//            {children}
//        </TitleNameContext.Provider>
//    );
//}
