// import React from 'react';
// import '@toast-ui/editor/dist/toastui-editor.css';
// import { Editor } from '@toast-ui/react-editor';

const ToastUiEditor = () => {
  return (
    <div>
      {/* <Editor /> */}
    </div>
  );
};

export default ToastUiEditor;
